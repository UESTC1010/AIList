import { readFile, readdir, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(fileURLToPath(import.meta.url));
async function walk(dir) {
  const files = [];
  for (const item of await readdir(dir, { withFileTypes: true })) {
    const name = path.join(dir, item.name);
    if (item.isDirectory() && !item.name.startsWith('.')) files.push(...await walk(name));
    else if (item.isFile() && item.name.endsWith('.html')) files.push(name);
  }
  return files;
}
const htmlFiles = (await walk(root)).filter(p => !p.includes(`${path.sep}content${path.sep}`));
const errors = [];
let links = 0;
for (const file of htmlFiles) {
  const html = await readFile(file, 'utf8');
  if (!html.includes('lang="zh-CN"') || !html.includes('<title>')) errors.push(`${file} 缺少标题或语言`);
  for (const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const ref = match[1].replace(/&amp;/g, '&');
    if (/^(https?:|data:|mailto:|tel:)/.test(ref)) continue;
    const [withoutHash, hash] = ref.split('#');
    const pathname = withoutHash.split('?')[0];
    const target = pathname ? path.resolve(path.dirname(file), decodeURIComponent(pathname)) : file;
    if (!target.startsWith(root + path.sep) && target !== root) { errors.push(`${file} 越界链接 ${ref}`); continue; }
    try { const entry = await stat(target); if (!entry.isFile()) errors.push(`${file} 链接不是文件 ${ref}`); }
    catch { errors.push(`${file} 链接缺失 ${ref}`); continue; }
    if (hash && target.endsWith('.html')) {
      const targetHtml = target === file ? html : await readFile(target, 'utf8');
      if (!targetHtml.includes(`id="${hash}"`)) errors.push(`${file} 锚点不存在 ${ref}`);
    }
    links++;
  }
}
const home = await readFile(path.join(root, 'index.html'), 'utf8');
const tools = JSON.parse(await readFile(path.join(root, 'content/tools.json'), 'utf8'));
if ((home.match(/data-group="/g) || []).length !== 6) errors.push('首页分类数不是 6');
if ((home.match(/data-tool-id="/g) || []).length !== 44) errors.push('首页工具数不是 44');
if (!home.includes('data-category="popular" aria-pressed="true"') || home.includes('data-category="all"')) errors.push('默认筛选应为热门，筛选栏不应有全部标签');
const homeCards = [...home.matchAll(/<article class="tool-card"([^>]+)>/g)];
if (homeCards.filter(card => !/\bhidden\b/.test(card[1])).length !== 12) errors.push('首页默认应仅显示 12 个热门工具');
if ((home.match(/data-popular="true"/g) || []).length !== 12) errors.push('首页热门标记数量不是 12');
if (!home.includes('class="tool-grid popular-view"') || !home.includes('<details class="directory-fallback">')) errors.push('缺少紧凑热门布局或无脚本完整列表入口');
for (const tool of tools) {
  const detail = await readFile(path.join(root, 'tools', `${tool.id}.html`), 'utf8');
  if (!detail.includes('第一次可以这样试') || !detail.includes('继续了解')) errors.push(`${tool.name} 介绍不完整`);
  if (!detail.includes(`id="example-${tool.id}"`) || !detail.includes('适合谁')) errors.push(`${tool.name} 缺少适用人群或任务示例`);
}
if (errors.length) { console.error(errors.join('\n')); process.exitCode = 1; }
else console.log(`通过：${htmlFiles.length} 个 HTML 页面、${links} 处站内链接与资源引用；6 个分类、44 个完整工具页。`);
