# AI 探新社

好用的 AI，比你知道的更多。

网站正式地址为 [https://tanxinshe.cn/](https://tanxinshe.cn/)，由 GitHub Pages 托管。它包含 6 个分类、44 个工具介绍页、4 篇文章，以及关于本站与隐私说明。首页默认展示 12 个热门工具，按分类或通过搜索可查找完整目录。搜索和分类在浏览器中执行，收藏保存在当前浏览器；不需要数据库或第三方 API 密钥。

## 先看网站

直接用浏览器打开 `index.html`。页面和图片都在本目录内，工具详情和文章可以直接跳转。

也可以在此目录运行 `python3 -m http.server 8765 --bind 127.0.0.1`，然后访问 `http://127.0.0.1:8765/`。通过 HTTP 访问能更完整地使用浏览器的收藏和复制链接功能。

## 更新已上线的网站

当前仓库 [UESTC1010/AIList](https://github.com/UESTC1010/AIList) 通过 GitHub Actions 发布。修改内容并重新生成页面后，把完整的 `ai-tanxinshe` 文件夹压缩成 `ai-tanxinshe-site.zip`，替换仓库里的同名文件即可自动部署。压缩包里需保留 `ai-tanxinshe` 这个顶层文件夹。

## 在另一个仓库发布

1. 在你的 GitHub 账号下创建一个公开仓库，例如 `ai-tanxinshe`。
2. 把本目录的**内容**放到仓库根目录，让 `index.html` 位于根目录。保留空文件 `.nojekyll`。
3. 打开仓库 **Settings → Pages**，在 Source 中选择 **Deploy from a branch**。
4. 选择 `main` 分支和 `/(root)` 文件夹，保存。
5. 发布完成后，从 Pages 设置中的 **Visit site** 打开实际网站。

GitHub Free 的 Pages 使用公开仓库；具体步骤见 [GitHub 官方发布说明](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)。

## 域名和搜索收录

`content/site.json` 中的 `baseUrl` 为 `https://tanxinshe.cn/`。运行 `node build.mjs` 后，生成器会为各页面添加该域名下的 canonical 链接，并生成相应的 `sitemap.xml` 和 `robots.txt`。网站使用自定义域名时，地址不包含 `/AIList/` 仓库路径。

在仓库 **Settings → Pages → Custom domain** 中绑定 `tanxinshe.cn`，再在西部数码配置 DNS。根域名的 `@` 主机记录使用 GitHub Pages 的 A 记录；`www` 使用 CNAME 指向 `uestc1010.github.io`，不包含仓库名。当前通过 GitHub Actions 部署，域名设置保存在 Pages 配置中，无需在网站文件中添加 `CNAME` 文件。DNS 检查通过且证书可用后，在 Pages 设置中启用 **Enforce HTTPS**。具体记录与设置以 [GitHub 官方自定义域名说明](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site) 为准。

## 修改工具或文章

- `content/tools.json`：工具名称、分类、官网、简介、适用人群、用途、任务示例、入门步骤与资料来源。
- `content/articles.json`：文章标题、摘要、段落、封面与关联工具。
- `content/site.json`：站点文案、更新时间、正式地址与 `popularTools` 首页热门工具 ID。
- `assets/style.css`：配色、布局和响应式样式。
- `assets/app.js`：搜索、分类、收藏与复制链接。

编辑内容后，在此目录运行：

```sh
node build.mjs
node check.mjs
```

无需安装 npm 包。发布时上传重新生成的 HTML、`assets/` 和 `.nojekyll`；或者直接上传整个目录。网站使用相对路径，兼容 GitHub Pages 项目路径和自定义域名。

当前生成器会检查 44 个工具、每类 5–8 个，以及必须收录的工具。如果以后更改总数量，需要同时调整 `build.mjs`、`check.mjs` 中的数量检查和首页文案。

## 内容说明

工具介绍依据官方资料整理，文中给出官方来源。文章为功能介绍与使用建议，没有写成亲测评分。本站当前不含广告、访问统计、登录功能或联盟追踪链接。以后加入这些服务时，请同步更新隐私和推广披露。

文章封面与站点图形保存在 `assets/`，没有外部图片、字体或图标下载依赖。
