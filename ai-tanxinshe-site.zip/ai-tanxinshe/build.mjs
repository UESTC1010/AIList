import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const read = p => readFile(path.join(root, p), 'utf8');
const write = async (p, content) => {
  await mkdir(path.dirname(path.join(root, p)), { recursive: true });
  await writeFile(path.join(root, p), content, 'utf8');
};
const site = JSON.parse(await read('content/site.json'));
const tools = JSON.parse(await read('content/tools.json'));
const articles = JSON.parse(await read('content/articles.json'));
const icons = await read('content/icons.html');
const versionOf = content => createHash('sha256').update(content).digest('hex').slice(0, 10);
const styleVersion = versionOf(await read('assets/style.css'));
const appVersion = versionOf(await read('assets/app.js'));
const dataVersion = versionOf(JSON.stringify(tools));
const categories = [
  { id: 'chat', name: '聊天与写作', icon: 'chat', description: '讨论想法、组织文字，找一个合拍的日常助手。' },
  { id: 'research', name: '学术与研究', icon: 'book', description: '从找文献、读论文，到投稿前多一轮反馈。' },
  { id: 'office', name: '办公与设计', icon: 'office', description: '演示文稿、会议记录与视觉内容，从一份初稿开始。' },
  { id: 'creative', name: '图片与视频', icon: 'image', description: '让一个画面、一段故事，成为看得见的作品。' },
  { id: 'audio', name: '配音与音乐', icon: 'audio', description: '为文字找到声音，为灵感找到旋律。' },
  { id: 'code', name: '编程与开发', icon: 'code', description: '看懂代码、修改项目，把一个需求变成可运行的功能。' }
];
const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = name => `<svg aria-hidden="true"><use href="#${name}"/></svg>`;
const categoryOf = id => categories.find(c => c.id === id);
const safeUrl = url => { if (!/^https:\/\//.test(url)) throw new Error(`需要 HTTPS 官网链接：${url}`); return esc(url); };

if (tools.length !== 44) throw new Error(`应有 44 个工具，实际 ${tools.length}`);
if (new Set(tools.map(t => t.id)).size !== tools.length) throw new Error('工具 ID 重复');
for (const t of tools) {
  if (!/^[a-z0-9-]+$/.test(t.id) || !categoryOf(t.category)) throw new Error(`无效的工具 ID / 分类：${t.id}`);
  for (const key of ['name','kind','description','url','audience','use','note']) if (!t[key]) throw new Error(`${t.id} 缺少 ${key}`);
  for (const key of ['title','input','action','result']) if (!t.example?.[key]) throw new Error(`${t.id} 缺少示例 ${key}`);
  for (const key of ['tasks','steps','tags','sources']) if (!Array.isArray(t[key]) || !t[key].length) throw new Error(`${t.id} 缺少 ${key}`);
  safeUrl(t.url);
  for (const source of t.sources) safeUrl(source.url);
  if (!/^#[0-9a-f]{6}$/i.test(t.bg) || !/^#[0-9a-f]{6}$/i.test(t.color)) throw new Error(`${t.id} 颜色格式错误`);
}
for (const c of categories) {
  const count = tools.filter(t => t.category === c.id).length;
  if (count < 5 || count > 8) throw new Error(`${c.name} 数量超出 5–8：${count}`);
}
for (const name of ['ChatGPT','Gemini','Claude','Grok','Stanford Agentic Reviewer','CSPaper']) {
  if (!tools.some(t => t.name === name)) throw new Error(`缺少必须收录的工具：${name}`);
}
const orderedTools = categories.flatMap(c => tools.filter(t => t.category === c.id));
const active = (current, name) => current === name ? ' class="nav-active" aria-current="page"' : '';
function header(r, current) {
  return `<header class="header"><div class="container header-inner">
    <a class="brand" href="${r}index.html" aria-label="AI 探新社首页"><span class="brand-symbol" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span class="brand-name"><span>AI</span>探新社</span></a>
    <nav class="nav" aria-label="主导航"><a href="${r}index.html#tools"${active(current, 'tools')}>工具导航</a><a href="${r}articles/index.html"${active(current, 'articles')}>精选文章</a><a class="about-nav" href="${r}about.html"${active(current, 'about')}>关于探新社</a></nav>
    <div class="header-end"><a class="bookmark-nav" href="${r}index.html?saved=1#tools" id="show-favorites" aria-label="查看我的收藏">${icon('bookmark')}<span class="bookmark-text">我的收藏</span><span class="bookmark-count" id="bookmark-count">0</span></a></div>
  </div></header>`;
}
function footer(r) {
  return `<footer class="footer"><div class="container"><div class="footer-inner"><div class="footer-brand">AI 探新社<span class="footer-tagline">AI 工具导航与精选介绍</span></div><div class="footer-links"><a href="${r}index.html#tools">工具导航</a><a href="${r}articles/index.html">精选文章</a><a href="${r}about.html">关于本站</a><a href="${r}privacy.html">隐私说明</a></div></div><div class="footer-small"><span>© 2026 AI 探新社</span><span>按用途发现工具 · 内容更新于 ${esc(site.updated)}</span></div></div></footer>`;
}
function page(title, description, body, { r = './', current = 'tools', home = false, file = '', structured = null } = {}) {
  const base = site.baseUrl ? site.baseUrl.replace(/\/$/, '') + '/' : '';
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="${esc(description)}"><meta name="theme-color" content="#faf9f6"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(description)}"><meta property="og:type" content="${current === 'articles' ? 'article' : 'website'}"><title>${esc(title)}</title><link rel="icon" type="image/svg+xml" href="${r}assets/favicon.svg"><link rel="stylesheet" href="${r}assets/style.css?v=${styleVersion}">${base && file ? `<link rel="canonical" href="${esc(base + file)}">` : ''}${structured ? `<script type="application/ld+json">${JSON.stringify(structured).replace(/</g, '\\u003c')}</script>` : ''}</head>
<body data-home="${home}" data-root="${r}"><a class="skip-link" href="#main-content">跳到主要内容</a>${icons}${header(r, current)}${body}${footer(r)}<div class="toast" id="toast" role="status" aria-live="polite"></div><script src="${r}assets/data.js?v=${dataVersion}" defer></script><script src="${r}assets/app.js?v=${appVersion}" defer></script></body></html>`;
}
function logo(t) { return `<span class="tool-logo" style="background:${t.bg};color:${t.color}" aria-hidden="true">${esc(t.mark)}</span>`; }
function toolExample(t) {
  const e = t.example;
  return `<section class="task-example" aria-labelledby="example-${t.id}"><span class="example-kicker">从一个小任务开始</span><h3 id="example-${t.id}">${esc(e.title)}</h3><dl><div><dt>准备什么</dt><dd>${esc(e.input)}</dd></div><div><dt>怎样尝试</dt><dd>${esc(e.action)}</dd></div><div><dt>目标结果</dt><dd>${esc(e.result)}</dd></div></dl></section>`;
}
function card(t, r = './') {
  return `<article class="tool-card" data-tool-id="${esc(t.id)}"><div class="card-top">${logo(t)}<div class="tool-title-block"><div class="tool-title"><a href="${r}tools/${t.id}.html">${esc(t.name)}</a></div><span class="tool-kind">${esc(t.kind)}</span></div><button class="favorite" type="button" data-favorite="${t.id}" aria-label="收藏 ${esc(t.name)}" aria-pressed="false">${icon('bookmark')}</button></div><p class="card-description">${esc(t.description)}</p><div class="tool-tags">${t.tags.map(tag => `<span class="tool-tag">${esc(tag)}</span>`).join('')}</div><div class="card-foot"><a class="detail-link" href="${r}tools/${t.id}.html">了解工具 ${icon('arrow')}</a><a href="${safeUrl(t.url)}" target="_blank" rel="noopener noreferrer" aria-label="访问 ${esc(t.name)} 官网（新窗口）">官网 ${icon('external')}</a></div></article>`;
}
function group(c) {
  const items = orderedTools.filter(t => t.category === c.id);
  return `<section class="category-section" data-group="${c.id}" aria-labelledby="group-${c.id}"><div class="category-heading"><div><h3 id="group-${c.id}">${icon(c.icon)}${c.name}<span>${items.length} 个工具</span></h3><p>${c.description}</p></div><a href="?category=${c.id}#tools" data-category-link="${c.id}">只看这一类 ${icon('arrow')}</a></div><div class="tool-grid">${items.map(t => card(t)).join('')}</div></section>`;
}
function articleCard(a, r) {
  return `<article class="article-card"><a class="article-image-button" href="${r}articles/${a.id}.html"><img src="${r}assets/${a.cover}" alt="${esc(a.coverAlt)}" width="640" height="360" loading="lazy"></a><div class="article-meta"><span class="article-category">${esc(a.category)}</span><i></i><span>${esc(a.type)} · ${a.minutes} 分钟</span></div><a class="article-title" href="${r}articles/${a.id}.html">${esc(a.title)}</a><p class="article-summary">${esc(a.summary)}</p><a class="article-read" href="${r}articles/${a.id}.html">读这篇介绍 ${icon('arrow')}</a></article>`;
}
const featuredArticles = articles.filter(a => a.featured);
await write('index.html', page(`${site.name} · ${site.slogan}`, site.description, `
<main class="container" id="main-content">
<section class="hero" aria-labelledby="hero-title"><div><div class="hero-eyebrow"><span class="status-dot"></span>AI 工具导航与精选介绍</div><h1 id="hero-title">好用的 AI，<br><span class="accent">比你知道的更多。</span></h1><p class="hero-description">发现你还没见过的 AI 工具，<br>了解它们能帮你做些什么。</p>
<form class="search-form" id="search-form" role="search"><svg aria-hidden="true"><use href="#search"/></svg><input id="tool-search" type="search" placeholder="搜索工具、用途，或你想做的事…" aria-label="搜索 AI 工具" autocomplete="off"><button type="submit">找工具</button></form><div class="search-hints"><span>试试搜</span><button type="button" data-search="论文评审">论文评审</button><button type="button" data-search="写作">写作助手</button><button type="button" data-search="编程">AI 编程</button><button type="button" data-search="演示">做演示文稿</button></div></div>
<aside class="hero-note" aria-label="入门指南"><div class="note-top"><span>THE STARTER GUIDE</span><span>入门指南</span></div><div class="note-title">先问需求，<br>再选工具。</div><div class="note-summary">从一件想完成的事开始，<br>找到适合自己的 AI 工具。</div><div class="note-bottom"><a href="articles/starter-guide.html">阅读这份指南 ${icon('arrow')}</a></div><div class="note-deco" aria-hidden="true"><svg viewBox="0 0 140 140"><circle cx="70" cy="70" r="54"/><circle cx="70" cy="70" r="40"/><path d="M70 9v12m0 98v12M9 70h12m98 0h12M28 28l9 9m66 66 9 9M28 112l9-9m66-66 9-9"/><path d="m49 91 13-29 29-13-13 29z"/><path d="m62 62 16 16"/></svg></div></aside></section>
<div class="intro-strip"><span>${icon('check')}6 个用途分类</span><span>${icon('check')}44 个精选工具</span><span>${icon('check')}收藏你的工具箱</span><span class="strip-right">STAY CURIOUS. FIND SOMETHING USEFUL.</span></div>
<section class="tools-section" id="tools" aria-labelledby="tools-title"><div class="section-heading"><div class="heading-left"><h2 id="tools-title">发现你的下一个<em>好工具</em></h2><span class="heading-caption">从具体需求出发</span></div><button class="section-action" type="button" id="reset-tools">浏览全部 ${icon('arrow')}</button></div>
<div class="filterbar"><div class="categories" role="group" aria-label="按用途筛选"><button class="category active" type="button" data-category="all" aria-pressed="true">${icon('grid')}全部</button>${categories.map(c => `<button class="category" type="button" data-category="${c.id}" aria-pressed="false">${icon(c.icon)}${c.name}</button>`).join('')}</div></div>
<div class="result-status"><span id="result-status" role="status" aria-live="polite">全部分类 · 44 个工具</span><button id="clear-search" class="text-button" type="button" hidden>清除搜索与筛选</button></div><div id="tool-groups">${categories.map(group).join('')}</div><div class="empty-state" id="empty-state" hidden><h3>暂时没有找到匹配的工具</h3><p>换个用途或关键词试试。</p><button type="button" data-reset>查看全部工具</button></div><noscript><p class="noscript-note">所有工具与介绍页都可以直接浏览。搜索、分类筛选与收藏需要浏览器启用 JavaScript。</p></noscript></section>
<section class="editorial-section" id="articles" aria-labelledby="articles-title"><div class="section-heading"><div class="heading-left"><h2 id="articles-title">工具之外，<em>多一点了解</em></h2><span class="heading-caption">精选介绍与使用指南</span></div><a class="section-action" href="articles/index.html">全部文章 ${icon('arrow')}</a></div><div class="article-grid">${featuredArticles.map(a => articleCard(a, './')).join('')}</div></section>
<aside class="closing"><div class="closing-icon" aria-hidden="true">✳</div><div><h3>工具会更新，好奇心一直在。</h3><p>把适合你的工具收藏起来，下次需要时，少绕一点路。</p></div><a href="#tools">去发现好工具 ${icon('arrow')}</a></aside></main>`, { home: true, file: 'index.html' }));

for (const t of orderedTools) {
  const c = categoryOf(t.category);
  const related = orderedTools.filter(x => x.category === t.category && x.id !== t.id).slice(0, 3);
  await write(`tools/${t.id}.html`, page(`${t.name} · 工具介绍 · ${site.name}`, t.description, `
<main class="container detail-main" id="main-content"><nav class="breadcrumb" aria-label="当前位置"><a href="../index.html">首页</a><span>/</span><a href="../index.html?category=${c.id}#tools">${c.name}</a><span>/</span><span>${esc(t.name)}</span></nav><div class="detail-layout"><article class="detail-article"><div class="detail-kicker">${c.name} / 工具介绍</div><div class="detail-tool-heading">${logo(t)}<div><h1>${esc(t.name)}</h1><p>${esc(t.kind)}</p></div></div><p class="detail-lead">${esc(t.description)}</p><div class="tool-tags">${t.tags.map(tag => `<span class="tool-tag">${esc(tag)}</span>`).join('')}</div><div class="tool-audience"><strong>适合谁</strong><p>${esc(t.audience)}</p></div><section class="prose"><h2>它能帮你做什么？</h2><p>${esc(t.use)}</p><ul>${t.tasks.map(task => `<li>${esc(task)}</li>`).join('')}</ul>${toolExample(t)}<h2>第一次可以这样试</h2><ol class="step-list">${t.steps.map(step => `<li>${esc(step)}</li>`).join('')}</ol><div class="reading-note"><h3>使用时留意</h3><p>${esc(t.note)}</p></div><h2>继续了解</h2><ul class="source-list">${t.sources.map(s => `<li><a href="${safeUrl(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)} ${icon('external')}</a></li>`).join('')}</ul><p class="content-date">依据官方资料整理 · 更新于 ${esc(site.updated)}</p></section></article><aside class="detail-sidebar"><div class="sidebar-box"><span class="eyebrow">TRY THIS TOOL</span><h2>从官网开始</h2><p>了解当前功能与使用方式，准备一个小任务试试。</p><a class="primary-button" href="${safeUrl(t.url)}" target="_blank" rel="noopener noreferrer">访问 ${esc(t.name)} 官网 ${icon('external')}</a><button class="save-detail" type="button" data-favorite="${t.id}" aria-label="收藏 ${esc(t.name)}" aria-pressed="false">${icon('bookmark')}<span data-save-label>收藏这个工具</span></button><button class="copy-link text-button" type="button">${icon('link')}复制本页链接</button></div><a class="back-link" href="../index.html?category=${c.id}#tools">${icon('arrow')}继续发现${c.name}工具</a></aside></div><section class="related-section"><div class="section-heading"><h2>同类工具，也可以看看</h2><a class="section-action" href="../index.html?category=${c.id}#tools">浏览这个分类 ${icon('arrow')}</a></div><div class="tool-grid">${related.map(x => card(x, '../')).join('')}</div></section></main>`, { r: '../', file: `tools/${t.id}.html` }));
}
for (const a of articles) {
  const related = (a.tools || []).map(id => orderedTools.find(t => t.id === id));
  if (related.some(t => !t)) throw new Error(`${a.id} 文章关联的工具不存在`);
  await write(`articles/${a.id}.html`, page(`${a.title} · ${site.name}`, a.summary, `
<main class="container detail-main" id="main-content"><nav class="breadcrumb" aria-label="当前位置"><a href="../index.html">首页</a><span>/</span><a href="index.html">精选文章</a><span>/</span><span>${esc(a.type)}</span></nav><div class="article-layout"><article class="long-article"><div class="detail-kicker">${esc(a.category)} / ${esc(a.type)}</div><h1>${esc(a.title)}</h1><p class="detail-lead">${esc(a.summary)}</p><div class="article-byline"><span>AI 探新社编辑</span><span>${esc(site.updated)}</span><span>约 ${a.minutes} 分钟</span><button class="copy-link text-button" type="button">${icon('link')}复制链接</button></div><img class="article-cover" src="../assets/${a.cover}" alt="${esc(a.coverAlt)}" width="640" height="360"><div class="prose"><p>${esc(a.intro)}</p>${a.sections.map((s, i) => `<section id="section-${i + 1}"><h2>${esc(s.title)}</h2>${(s.paragraphs || []).map(p => `<p>${esc(p)}</p>`).join('')}${s.bullets ? `<ul>${s.bullets.map(p => `<li>${esc(p)}</li>`).join('')}</ul>` : ''}${s.quote ? `<blockquote>${esc(s.quote)}</blockquote>` : ''}</section>`).join('')}${a.sources?.length ? `<h2>资料来源</h2><ul class="source-list">${a.sources.map(s => `<li><a href="${safeUrl(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)} ${icon('external')}</a></li>`).join('')}</ul>` : ''}</div><a class="back-link" href="index.html">${icon('arrow')}回到精选文章</a></article><aside class="article-toc" aria-label="文章目录"><span class="eyebrow">IN THIS ARTICLE</span><h2>这篇文章聊什么</h2>${a.sections.map((s, i) => `<a href="#section-${i + 1}">${esc(s.title)}</a>`).join('')}</aside></div>${related.length ? `<section class="related-section"><div class="section-heading"><h2>文中提到的工具</h2></div><div class="tool-grid">${related.map(t => card(t, '../')).join('')}</div></section>` : ''}</main>`, { r: '../', current: 'articles', file: `articles/${a.id}.html` }));
}
await write('articles/index.html', page(`精选文章 · ${site.name}`, '从工具介绍到入门方法，慢一点了解 AI，找到适合自己的使用方式。', `<main class="container collection-main" id="main-content"><div class="collection-heading"><div class="hero-eyebrow"><span class="status-dot"></span>FIELD NOTES</div><h1>工具之外，<em>多一点了解。</em></h1><p>从一篇清楚的介绍开始，认识一个工具，也认识一种新的做事方式。</p></div><div class="article-grid">${articles.map(a => articleCard(a, '../')).join('')}</div></main>`, { r: '../', current: 'articles', file: 'articles/index.html' }));

await write('about.html', page(`关于探新社 · ${site.name}`, '认识更多好用的 AI。了解 AI 探新社如何选择工具、整理介绍。', `<main class="container collection-main" id="main-content"><article class="about-content"><div class="hero-eyebrow"><span class="status-dot"></span>ABOUT US</div><h1>认识更多好用的 AI。</h1><p class="detail-lead">AI 工具层出不穷。我们希望你从一个具体需求出发，找到此前不知道、又可能帮得上忙的工具。</p><div class="prose"><h2>每张卡片，是一个认识工具的起点</h2><p>这里按用途整理 44 个工具，覆盖聊天与写作、学术与研究、办公与设计、图片与视频、配音与音乐、编程与开发。卡片告诉你它能做什么，介绍页提供具体任务和入门方法，再把你带到官方网站。</p><h2>介绍清楚，再谈选择</h2><p>工具资料依据官网与官方说明整理。我们优先写明用途、适合尝试的任务，以及使用时需要留意的地方。文章中的功能介绍与使用建议不代表亲自测试过所有工具。</p><p>目前站内链接直接指向工具官网，未使用联盟追踪链接。若后续加入推广合作，会在对应位置清楚标注。</p><h2>让工具箱保持轻一点</h2><p>不必同时尝试所有工具。选择一两个与你当前任务相关的工具，从一小份素材开始，把适合自己的留下来。</p><a class="primary-button" href="index.html#tools">去发现好工具 ${icon('arrow')}</a></div></article></main>`, { current: 'about', file: 'about.html' }));
await write('privacy.html', page(`隐私说明 · ${site.name}`, '了解本站的浏览器收藏、外部链接及数据处理方式。', `<main class="container collection-main" id="main-content"><article class="about-content"><div class="detail-kicker">隐私说明</div><h1>你的工具箱，留在你的浏览器里。</h1><div class="prose"><h2>收藏如何保存</h2><p>收藏的工具编号保存在当前浏览器的本地存储中，不上传至本站服务器。更换设备、切换浏览器或清除网站数据后，收藏不会自动同步。你可以逐个取消收藏来删除这些记录。</p><h2>搜索与浏览</h2><p>工具搜索和分类筛选在浏览器内完成。本站目前没有账号系统、广告脚本或第三方访问统计。若发布于 GitHub Pages，托管服务会按照其自身规则处理网络请求记录。</p><h2>访问工具官网</h2><p>点击官网链接后，你会进入第三方网站。登录、上传内容或购买服务时，适用该网站的隐私与服务条款。</p><p class="content-date">更新于 ${esc(site.updated)}</p></div></article></main>`, { current: 'about', file: 'privacy.html' }));

await write('assets/data.js', `window.AI_TANXINSHE_DATA = ${JSON.stringify({ categories, tools: orderedTools, updated: site.updated }).replace(/</g, '\\u003c')};\n`);
await write('.nojekyll', '');
if (site.baseUrl) {
  const base = site.baseUrl.replace(/\/$/, '') + '/';
  const files = ['index.html','about.html','privacy.html','articles/index.html', ...tools.map(t => `tools/${t.id}.html`), ...articles.map(a => `articles/${a.id}.html`)];
  await write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${files.map(f => `<url><loc>${esc(base + f)}</loc><lastmod>${site.updated}</lastmod></url>`).join('')}</urlset>`);
  await write('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${base}sitemap.xml\n`);
} else {
  await rm(path.join(root, 'sitemap.xml'), { force: true });
  await write('robots.txt', 'User-agent: *\nAllow: /\n');
}
console.log(`已生成：${tools.length} 个工具页、${articles.length} 篇文章、6 个分类及首页。`);
