(() => {
  'use strict';
  const data = window.AI_TANXINSHE_DATA;
  if (!data) return;
  const byId = new Map(data.tools.map(tool => [tool.id, tool]));
  const storageKey = 'ai-tanxinshe-favorites';
  let favorites = new Set();
  let canPersist = true;
  let toastTimer;
  try {
    const raw = localStorage.getItem(storageKey) ?? localStorage.getItem('ai-shiguang-favorites') ?? '[]';
    const saved = JSON.parse(raw);
    if (Array.isArray(saved)) favorites = new Set(saved.filter(id => byId.has(id)));
  } catch { canPersist = false; }
  function toast(message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('visible'), 2400);
  }
  function syncFavorites() {
    const count = document.getElementById('bookmark-count');
    if (count) count.textContent = favorites.size;
    document.querySelectorAll('[data-favorite]').forEach(button => {
      const saved = favorites.has(button.dataset.favorite);
      const tool = byId.get(button.dataset.favorite);
      button.setAttribute('aria-pressed', String(saved));
      button.setAttribute('aria-label', `${saved ? '取消收藏' : '收藏'} ${tool?.name || ''}`);
      const label = button.querySelector('[data-save-label]');
      if (label) label.textContent = saved ? '已收藏 · 点击取消' : '收藏这个工具';
    });
  }
  const home = document.body.dataset.home === 'true';
  const input = document.getElementById('tool-search');
  const validCategories = new Set(['all', ...data.categories.map(c => c.id)]);
  let state = { category: 'all', q: '', saved: false };
  function readLocation() {
    const p = new URLSearchParams(location.search);
    state = { category: validCategories.has(p.get('category')) ? p.get('category') : 'all', q: (p.get('q') || '').slice(0, 200), saved: p.get('saved') === '1' };
    if (input) input.value = state.q;
  }
  function writeLocation() {
    const p = new URLSearchParams();
    if (state.category !== 'all') p.set('category', state.category);
    if (state.q) p.set('q', state.q);
    if (state.saved) p.set('saved', '1');
    const next = `${location.pathname}${p.size ? `?${p}` : ''}${location.hash}`;
    try { history.replaceState(null, '', next); } catch { /* file preview may restrict history writes */ }
  }
  function searchText(tool) {
    const reviewTerms = ['stanford-agentic-reviewer', 'cspaper'].includes(tool.id) ? '论文评审 论文预审 审稿 投稿修改 paper review' : '';
    return [tool.name, tool.kind, tool.description, tool.use, ...tool.tags, ...tool.tasks, categoryName(tool.category), reviewTerms].join(' ').normalize('NFKC').toLowerCase();
  }
  function categoryName(id) { return data.categories.find(c => c.id === id)?.name || '全部分类'; }
  const searchable = new Map(data.tools.map(tool => [tool.id, searchText(tool)]));
  function renderFilters(updateUrl = true) {
    if (!home) return;
    const query = state.q.trim().normalize('NFKC').toLowerCase();
    const terms = query.split(/\s+/).filter(Boolean);
    const matches = new Set(data.tools.filter(tool =>
      (state.category === 'all' || tool.category === state.category) &&
      (!state.saved || favorites.has(tool.id)) &&
      terms.every(term => searchable.get(tool.id).includes(term))
    ).map(tool => tool.id));
    document.querySelectorAll('#tool-groups [data-tool-id]').forEach(card => { card.hidden = !matches.has(card.dataset.toolId); });
    document.querySelectorAll('[data-group]').forEach(group => {
      const count = [...group.querySelectorAll('[data-tool-id]')].filter(card => !card.hidden).length;
      group.hidden = count === 0;
      const label = group.querySelector('.category-heading h3 span');
      if (label) label.textContent = `${count} 个工具`;
    });
    document.querySelectorAll('button[data-category]').forEach(button => {
      const selected = button.dataset.category === state.category;
      button.classList.toggle('active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    const favoriteNav = document.getElementById('show-favorites');
    favoriteNav.classList.toggle('is-active', state.saved);
    favoriteNav.setAttribute('aria-label', state.saved ? '显示全部工具' : '查看我的收藏');
    const status = [state.saved ? '我的收藏' : categoryName(state.category), state.q ? `“${state.q}”` : '', `${matches.size} 个工具`].filter(Boolean).join(' · ');
    document.getElementById('result-status').textContent = status;
    document.getElementById('clear-search').hidden = !(state.q || state.saved || state.category !== 'all');
    const empty = document.getElementById('empty-state');
    empty.hidden = matches.size !== 0;
    empty.querySelector('h3').textContent = state.saved && favorites.size === 0 ? '你的工具箱还是空的' : '暂时没有找到匹配的工具';
    empty.querySelector('p').textContent = state.saved && favorites.size === 0 ? '点击工具卡片右上角的书签，把喜欢的工具留下来。' : '换个用途或关键词试试。';
    if (updateUrl) writeLocation();
  }
  function reset() { state = { category: 'all', q: '', saved: false }; input.value = ''; renderFilters(); }
  function scrollToTools() { document.getElementById('tools')?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); }
  function changeCategory(id) { state.category = id; state.saved = false; renderFilters(); }
  document.addEventListener('click', async event => {
    const favorite = event.target.closest('[data-favorite]');
    if (favorite) {
      const id = favorite.dataset.favorite;
      if (!byId.has(id)) return;
      const added = !favorites.has(id);
      if (added) favorites.add(id); else favorites.delete(id);
      try { localStorage.setItem(storageKey, JSON.stringify([...favorites])); canPersist = true; } catch { canPersist = false; }
      syncFavorites();
      renderFilters(false);
      toast(added ? (canPersist ? '已加入你的工具箱' : '已收藏，当前页面有效') : '已取消收藏');
      return;
    }
    const copy = event.target.closest('.copy-link');
    if (copy) {
      try {
        if (!navigator.clipboard) throw new Error('clipboard unavailable');
        await navigator.clipboard.writeText(location.href);
        toast('链接已复制');
      } catch { toast('请从浏览器地址栏复制本页链接'); }
      return;
    }
    if (!home) return;
    const categoryButton = event.target.closest('button[data-category]');
    if (categoryButton) { changeCategory(categoryButton.dataset.category); return; }
    const categoryLink = event.target.closest('[data-category-link]');
    if (categoryLink) { event.preventDefault(); changeCategory(categoryLink.dataset.categoryLink); scrollToTools(); return; }
    const search = event.target.closest('[data-search]');
    if (search) { state = { category: 'all', q: search.dataset.search, saved: false }; input.value = state.q; renderFilters(); scrollToTools(); return; }
    const resetButton = event.target.closest('#reset-tools, #clear-search, [data-reset]');
    if (resetButton) { reset(); return; }
    const saved = event.target.closest('#show-favorites');
    if (saved) { event.preventDefault(); const next = !state.saved; reset(); state.saved = next; renderFilters(); scrollToTools(); }
  });
  if (home) {
    readLocation();
    renderFilters(false);
    input.addEventListener('input', () => { state.q = input.value; renderFilters(); });
    document.getElementById('search-form').addEventListener('submit', event => { event.preventDefault(); renderFilters(); scrollToTools(); });
    addEventListener('popstate', () => { readLocation(); renderFilters(false); });
  }
  addEventListener('storage', event => {
    if (event.key !== storageKey && event.key !== null) return;
    try { const saved = JSON.parse(localStorage.getItem(storageKey) || '[]'); favorites = new Set(Array.isArray(saved) ? saved.filter(id => byId.has(id)) : []); } catch { return; }
    syncFavorites(); renderFilters(false);
  });
  syncFavorites();
})();
